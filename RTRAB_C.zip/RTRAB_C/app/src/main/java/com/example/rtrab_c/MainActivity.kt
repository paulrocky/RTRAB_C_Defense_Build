package com.example.rtrab_c

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.view.MotionEvent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Start at LOGIN. If they are already logged in, they will have to hit logout once to clear the old cache.
            var currentScreen by remember { mutableStateOf("LOGIN") }

            when (currentScreen) {
                "LOGIN" -> LoginScreen(
                    onLoginSuccess = { targetScreen -> currentScreen = targetScreen }, // Captures the role destination
                    onNavigateToSignUp = { currentScreen = "SIGNUP" }
                )
                "SIGNUP" -> SignUpScreen(
                    onSignUpSuccess = { targetScreen -> currentScreen = targetScreen }, // Captures the role destination
                    onNavigateToLogin = { currentScreen = "LOGIN" }
                )
                "HOME" -> PublicRiskMapScreen(
                    onNavigateToReport = { currentScreen = "REPORT" },
                    onLogout = { FirebaseAuth.getInstance().signOut(); currentScreen = "LOGIN" }
                )
                "REPORT" -> SubmitReportScreen(
                    onNavigateHome = { currentScreen = "HOME" }
                )
                "ADMIN_DASHBOARD" -> AdminDashboardScreen(
                    onLogout = { FirebaseAuth.getInstance().signOut(); currentScreen = "LOGIN" }
                )
            }
        }
    }
}

// ==========================================
// FIREBASE DATA MODEL
// ==========================================
// Firebase needs default values (="") to know how to download the data
data class HazardReport(
    val type: String = "",
    val description: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timestamp: Long = 0L,
    val reporterEmail: String = "",
    val status: String = ""
)

// SCREEN: REAL CLOUD LOGIN (CHECKS ROLES)
@Composable
fun LoginScreen(onLoginSuccess: (String) -> Unit, onNavigateToSignUp: () -> Unit) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.White).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painter = painterResource(id = R.drawable.rtrab_logo), contentDescription = "Logo", modifier = Modifier.size(100.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("RTRAB-C", color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold, fontSize = 32.sp)
        Text("City of Baguio", color = Color.Gray, fontSize = 16.sp)

        Spacer(modifier = Modifier.height(48.dp))

        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                if (email.isNotEmpty() && password.isNotEmpty()) {
                    isLoading = true
                    val auth = FirebaseAuth.getInstance()
                    val db = FirebaseFirestore.getInstance()

                    auth.signInWithEmailAndPassword(email.trim(), password)
                        .addOnSuccessListener { authResult ->
                            val userId = authResult.user?.uid ?: return@addOnSuccessListener

                            // Check the database for their role!
                            db.collection("users").document(userId).get()
                                .addOnSuccessListener { document ->
                                    isLoading = false
                                    val role = document.getString("role") ?: "CITIZEN"
                                    onLoginSuccess(if (role == "ADMIN") "ADMIN_DASHBOARD" else "HOME")
                                }
                                .addOnFailureListener {
                                    isLoading = false
                                    onLoginSuccess("HOME") // Default fallback
                                }
                        }
                        .addOnFailureListener { error ->
                            isLoading = false
                            Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_LONG).show()
                        }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
            enabled = !isLoading
        ) { Text(if (isLoading) "VERIFYING CREDENTIALS..." else "SECURE LOGIN", fontWeight = FontWeight.Bold) }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Don't have an account? Sign Up", color = Color(0xFF1976D2), modifier = Modifier.clickable { onNavigateToSignUp() })
    }
}


// SCREEN: REAL CLOUD SIGN UP (WITH ROLES)
@Composable
fun SignUpScreen(onSignUpSuccess: (String) -> Unit, onNavigateToLogin: () -> Unit) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isAdmin by remember { mutableStateOf(false) } // NEW: Admin toggle!
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.White).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Create Account", color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
        Text("Citizen Reporting Portal", color = Color.Gray, fontSize = 16.sp)

        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (Min 6 chars)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Checkbox to select Admin Role
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Checkbox(
                checked = isAdmin,
                onCheckedChange = { isAdmin = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFFD32F2F))
            )
            Text("Register as City Official (Admin)", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (email.isNotEmpty() && password.length >= 6) {
                    isLoading = true
                    val auth = FirebaseAuth.getInstance()
                    val db = FirebaseFirestore.getInstance()

                    // 1. Create the Auth Account
                    auth.createUserWithEmailAndPassword(email.trim(), password)
                        .addOnSuccessListener { authResult ->
                            val userId = authResult.user?.uid ?: return@addOnSuccessListener
                            val roleStr = if (isAdmin) "ADMIN" else "CITIZEN"

                            // 2. Save their Role into the Firestore Database
                            val userProfile = hashMapOf("email" to email.trim(), "role" to roleStr)

                            db.collection("users").document(userId).set(userProfile)
                                .addOnSuccessListener {
                                    isLoading = false
                                    Toast.makeText(context, "Account Created!", Toast.LENGTH_SHORT).show()
                                    // Pass the role back so the app knows where to send them
                                    onSignUpSuccess(if (isAdmin) "ADMIN_DASHBOARD" else "HOME")
                                }
                        }
                        .addOnFailureListener { error ->
                            isLoading = false
                            Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_LONG).show()
                        }
                } else {
                    Toast.makeText(context, "Invalid email or short password", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
            enabled = !isLoading
        ) { Text(if (isLoading) "REGISTERING..." else "REGISTER", fontWeight = FontWeight.Bold) }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Already have an account? Login", color = Color(0xFF1976D2), modifier = Modifier.clickable { onNavigateToLogin() })
    }
}

// ==========================================
// SCREEN: REAL-TIME CLOUD MAP DASHBOARD
// ==========================================
@Composable
fun PublicRiskMapScreen(onNavigateToReport: () -> Unit, onLogout: () -> Unit) {
    val context = LocalContext.current
    var activeAlerts by remember { mutableStateOf(listOf<HazardReport>()) }

    // ---> CLOCK <---
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            val formatter = SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
            currentTime = formatter.format(java.util.Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    // REAL-TIME CLOUD SYNC: This listens to the internet.
    // If anyone in the world adds a report, this updates instantly!
    DisposableEffect(Unit) {
        val db = FirebaseFirestore.getInstance()
        val listener = db.collection("reports").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Toast.makeText(context, "Map Sync Failed.", Toast.LENGTH_SHORT).show()
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val reports = snapshot.toObjects(HazardReport::class.java)
                activeAlerts = reports
            }
        }
        onDispose { listener.remove() } // Clean up when leaving screen
    }

    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(16.dp)) {

        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.rtrab_logo),
                contentDescription = "RTRAB-C Logo",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("RTRAB-C", color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                Text("Baguio Real-Time Risk\nAssessment", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                // live clock
                Text(currentTime, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier.background(Color(0xFF4CAF50), shape = RoundedCornerShape(4.dp)).padding(horizontal = 12.dp, vertical = 4.dp)
                ) { Text("LIVE MAP", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp) }
            }
            Text("Logout", color = Color.Red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onLogout() })
        }
            //map
        Spacer(modifier = Modifier.height(32.dp))

        Configuration.getInstance().userAgentValue = context.packageName
        AndroidView(
            factory = { mapContext ->
                MapView(mapContext).apply {
                    val cleanMapStyle = XYTileSource("CartoPositron", 1, 20, 256, ".png", arrayOf("https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/"))
                    setTileSource(cleanMapStyle)
                    setMultiTouchControls(false)
                    setOnTouchListener { _, _ -> true }
                    controller.setZoom(16.0)
                    controller.setCenter(GeoPoint(16.4164, 120.5930))
                }
            },
            update = { mapView ->
                // This forces the map to draw new pins the second they arrive from the cloud
                mapView.overlays.clear()
                activeAlerts.forEach { report ->
                    val marker = Marker(mapView)
                    marker.position = GeoPoint(report.latitude, report.longitude)
                    marker.title = report.description
                    marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    mapView.overlays.add(marker)
                }
                mapView.invalidate() // Refresh map graphics
            },
            modifier = Modifier.fillMaxWidth().height(100.dp)
        )

        Spacer(modifier = Modifier.height(90.dp))
        Text("Active Alerts (City-Wide):", color = Color(0xFF00796B), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(16.dp))

        if (activeAlerts.isEmpty()) {
            Text("No active alerts reported.", color = Color.Gray, fontSize = 14.sp)
        } else {
            activeAlerts.forEach { report ->
                AlertItem(title = "(!) ${report.description}", status = report.status)
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            NavButton(text = "HOME", onClick = { })
            NavButton(text = "REPORT", onClick = onNavigateToReport)
            NavButton(text = "ALERTS", onClick = { })
        }
    }
}


// SCREEN: SUBMIT REPORT (UI UPGRADED + SCROLL FIX)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubmitReportScreen(onNavigateHome: () -> Unit) {
    val context = LocalContext.current
    var description by remember { mutableStateOf("") }
    var mapViewReference: MapView? by remember { mutableStateOf(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    // Live Clock
    var currentTime by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val formatter = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
            currentTime = formatter.format(java.util.Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    // Real-Time Internet Status (Uses the tool we just built!)
    val isOnline by rememberNetworkStatus()

    // Dropdown State
    var expanded by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("Landslide") }
    val categories = listOf("Landslide", "Flood", "Fire", "Accident", "Other")

    // The Column now has verticalScroll so it doesn't get cut off!
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // HEADER MATCHING DESIGN
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.rtrab_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(70.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("RTRAB-C", color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                Text("Baguio Real-Time Risk\nAssessment", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // NAVIGATION & STATUS BADGES
        Button(
            onClick = onNavigateHome,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF154360)), // Dark Blue
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.height(40.dp)
        ) { Text("Home", color = Color.White, fontWeight = FontWeight.Bold) }

        Spacer(modifier = Modifier.height(8.dp))
        Text(if (currentTime.isEmpty()) "10:32 AM" else currentTime, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(4.dp))

        // SMART BADGE: Changes dynamically based on connection!

        val statusColor = if (isOnline) Color(0xFF3B5998) else Color(0xFF757575)
        val statusText = if (isOnline) "ONLINE" else "OFFLINE"

        Box(
            modifier = Modifier
                .background(statusColor, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(statusText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(40.dp))

        // MAP VIEW (WITH SCROLL FIX!)
        Box(modifier = Modifier.fillMaxWidth().height(100.dp)) {
            Configuration.getInstance().userAgentValue = context.packageName
            AndroidView(
                factory = { mapContext ->
                    MapView(mapContext).apply {
                        val cleanMapStyle = XYTileSource(
                            "CartoPositron",
                            1,
                            20,
                            256,
                            ".png",
                            arrayOf("https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/")
                        )
                        setTileSource(cleanMapStyle)
                        setMultiTouchControls(true)
                        controller.setZoom(17.0)
                        controller.setCenter(GeoPoint(16.4164, 120.5930))
                        mapViewReference = this


                        // STOPS THE SCREEN FROM SCROLLING WHEN YOU TOUCH THE MAP!
                        setOnTouchListener { view, event ->
                            when (event.action) {
                                // When your finger touches the map, tell the main screen to STOP scrolling
                                MotionEvent.ACTION_DOWN -> {
                                    view.parent.requestDisallowInterceptTouchEvent(true)
                                }
                                // When you lift your finger, allow the main screen to scroll again
                                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                    view.parent.requestDisallowInterceptTouchEvent(false)
                                }
                            }
                            // Pass the touch gesture directly to the map so it can actually drag!
                            view.onTouchEvent(event)
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Text("📍", fontSize = 42.sp, modifier = Modifier.align(Alignment.Center).offset(y = (-20).dp))
        }

        Spacer(modifier = Modifier.height(90.dp))

        // REPORT HAZARD DROPDOWN
        Text("Report Hazard", color = Color(0xFF00695C), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Box {
            Button(
                onClick = { expanded = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)), // Light Blue
                shape = RoundedCornerShape(4.dp)
            ) { Text("$selectedCategory  ▼", color = Color.White, fontWeight = FontWeight.Bold) }

            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                categories.forEach { category ->
                    DropdownMenuItem(
                        text = { Text(category, fontWeight = FontWeight.Bold) },
                        onClick = {
                            selectedCategory = category
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        // PHOTO EVIDENCE SECTION
        Text("Photo Evidence", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(50.dp).background(Color.White).border(2.dp, Color.Black, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) { Text("📷", fontSize = 24.sp) }

            Spacer(modifier = Modifier.width(30.dp))

            Button(
                onClick = { Toast.makeText(context, "Hardware Camera Setup Required", Toast.LENGTH_SHORT).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)), // Bright Red
                shape = RoundedCornerShape(4.dp)
            ) { Text("Take Photo", color = Color.White, fontWeight = FontWeight.Bold) }
        }

        Spacer(modifier = Modifier.height(40.dp))

        // DESCRIPTION TEXT BOX
        Text("Description Details", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = description,
            onValueChange = { description = it },
            placeholder = { Text("Type your text here", color = Color.Gray) },
            modifier = Modifier.fillMaxWidth().height(120.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFFE0E0E0),
                unfocusedContainerColor = Color(0xFFE0E0E0)
            ) // Light Gray matching image
        )

        Spacer(modifier = Modifier.height(40.dp))

        // SAVE REPORT BUTTON
        Button(
            onClick = {
                if (description.isNotEmpty()) {
                    isSubmitting = true
                    val centerPoint = mapViewReference?.mapCenter as? GeoPoint
                    val currentLat = centerPoint?.latitude ?: 16.4164
                    val currentLon = centerPoint?.longitude ?: 120.5930
                    val currentUserEmail = FirebaseAuth.getInstance().currentUser?.email ?: "Unknown"

                    val newReport = HazardReport(
                        type = selectedCategory,
                        description = description,
                        latitude = currentLat,
                        longitude = currentLon,
                        timestamp = System.currentTimeMillis(),
                        reporterEmail = currentUserEmail,
                        status = "PENDING"
                    )

                    FirebaseFirestore.getInstance().collection("reports")
                        .add(newReport)
                        .addOnSuccessListener {
                            isSubmitting = false
                            Toast.makeText(context, "Uploaded to City Servers!", Toast.LENGTH_SHORT).show()
                            description = ""
                            onNavigateHome()
                        }
                        .addOnFailureListener { e ->
                            isSubmitting = false
                            Toast.makeText(context, "Failed to upload: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                } else {
                    Toast.makeText(context, "Please enter a description.", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.align(Alignment.CenterHorizontally).fillMaxWidth(0.5f).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)), // Bright Red
            shape = RoundedCornerShape(4.dp),
            enabled = !isSubmitting
        ) { Text(if (isSubmitting) "SAVING..." else "Save Report", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        Spacer(modifier = Modifier.height(48.dp)) // Extra padding so it doesn't touch the bottom screen edge
    }
}

// ==========================================
// HELPER UI FUNCTIONS
// ==========================================
@Composable
fun AlertItem(title: String, status: String) {
    Column(modifier = Modifier.padding(bottom = 12.dp)) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Text("Status: $status", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Color.Red)
    }
}

@Composable
fun RowScope.NavButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336)),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.weight(1f).padding(horizontal = 4.dp).height(45.dp)
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
}

@Composable
fun AdminDashboardScreen(onLogout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color.White).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Admin Dashboard", color = Color(0xFFD32F2F), fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
        ) {
            Text("LOGOUT", fontWeight = FontWeight.Bold)
        }
    }
}
// ==========================================
// HELPER: LIVE INTERNET CHECKER
// ==========================================
@Composable
fun rememberNetworkStatus(): State<Boolean> {
    val context = LocalContext.current
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    val initialConnection = connectivityManager.activeNetwork?.let { network ->
        connectivityManager.getNetworkCapabilities(network)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } ?: false

    val isConnected = remember { mutableStateOf(initialConnection) }

    DisposableEffect(connectivityManager) {
        val networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { isConnected.value = true }
            override fun onLost(network: Network) { isConnected.value = false }
        }
        val request = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        connectivityManager.registerNetworkCallback(request, networkCallback)

        onDispose { connectivityManager.unregisterNetworkCallback(networkCallback) }
    }
    return isConnected
}